const http = require('http');

http.createServer((requisicao, resposta)=>{
    resposta.writeHead(200,{'Content-Type': 'text/plain'});
    resposta.write('Analise e Desenvolvimento de Sistemas');
    resposta.end();
}).listen(3000);

console.log('Servidor rodando - Projeto Iniciando');