const http = require('http');
const porta = 3000;
const host = '127.0.0.1';

const servidor = http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'})
if(req.url == '/'){
    res.write('<h1>ANALISE E DESENVOLVIMENTO DE SISTEMAS</h1>');
}
else if(req.url == '/disciplina'){
    res.write('<h2>Técnicas de Programação</h2>');
}
else if(req.url == '/semestre'){
    res.write('<h3>4°/5° Semestres </h3>')

}
res.end();

});

servidor.listen(porta,host,() =>(console.log('Servidor Rodando')))
